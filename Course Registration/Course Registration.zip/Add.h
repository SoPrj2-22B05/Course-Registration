#pragma once
void Add(string command, string studentid, string studentname);
