#pragma once
void Delete(string command, string studentid, string studentname);