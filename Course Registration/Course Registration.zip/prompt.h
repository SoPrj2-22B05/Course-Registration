#pragma once
//#include <string>

//using std::string;

void User_info_menu();
void print_manual();
void Student_menu();
void Adminisraor_menu();
void add_check(string str);
void add_help_print();
void del_check(string str);
void del_help_print();
void alter_check(string str);
void alter_help_print();
void find_help_print();
bool start_check();
