#pragma once
void Alter(string command, string studentid, string studentname);