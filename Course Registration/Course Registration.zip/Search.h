#pragma once
void Search(string command);
void Logout(string command);
