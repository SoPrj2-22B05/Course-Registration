#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <locale.h>
#include <vector>
#include <algorithm>
#include <atlconv.h>
#include "AttendanceStudentData.h"
using namespace std;

void Administrator_menu();
bool StartOrEnd(int command);
void Prioritizing();
void firstPriority(vector<Student>& v1, int& max, wstring subMajor, int& subGrade);
void secondPriority(vector<Student>& candidate, int& remainMax, wstring subMajor, int& subGrade);
void thirdPriority(vector<Student>& candidate, int& remainMax, int& subGrade);
void fourthPriority(vector<Student>& candidate, int& remainMax);
void fifthPriority(vector<Student>& candidate, int& remainMax);
void sixthPriority(vector<Student>& candidate, int& remainMax);
void PrintCandidateInfo(vector<Student>& candidateVec);