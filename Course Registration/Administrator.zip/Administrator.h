#pragma once

using namespace std;
void Administrator_menu();
bool StartOrEnd(int command);
void Prioritizing();
class Student {
private:
	string studentNum;
	string studentName;
	int mileage;
	int order;
public:
	Student(string studentNum, string name, int mileage, int order) {
		this->studentNum = studentNum;
		this->studentName = name;
		this->mileage = mileage;
		this->order = order;
	}
	void PrintStudentInfo() {
		cout << studentNum << " " << studentName << " " << mileage << " " << order << endl;
	}
	int GetMileage() {
		return this->mileage;
	}
	string GetStudentNum() {
		return this->studentNum;
	}
	string GetStudentName() {
		return this->studentName;
	}
};
